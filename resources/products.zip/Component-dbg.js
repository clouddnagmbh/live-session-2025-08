sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("my.ecommerce.products.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);